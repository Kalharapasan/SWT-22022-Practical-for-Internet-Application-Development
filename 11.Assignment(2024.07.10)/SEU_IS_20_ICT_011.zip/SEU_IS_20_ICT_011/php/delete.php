<?php
require '../database/BookICT011.php';
require '../database/DatabaseConnectionICT011.php';

$database = new DatabaseConnectionICT011("localhost", "root", "", "SEU_IS_20_ICT_011");
$connection = $database->getConnection();

$book = new BookICT011($connection);

$data = json_decode(file_get_contents("php://input"));

$book->setBookID($data->bookId);

if ($book->delete()) {
    echo json_encode(["message" => "Book deleted successfully"]);
} else {
    echo json_encode(["message" => "Unable to delete book"]);
}
?>
