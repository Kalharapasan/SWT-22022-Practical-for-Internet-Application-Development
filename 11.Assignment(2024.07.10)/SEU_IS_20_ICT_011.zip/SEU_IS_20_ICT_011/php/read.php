<?php
require '../database/BookICT011.php';
require '../database/DatabaseConnectionICT011.php';

$database = new DatabaseConnectionICT011("localhost", "root", "", "SEU_IS_20_ICT_011");
$connection = $database->getConnection();

$book = new BookICT011($connection);

$result = $book->read();

$books = [];
while ($row = $result->fetch_assoc()) {
    $books[] = $row;
}

echo json_encode($books);
?>
