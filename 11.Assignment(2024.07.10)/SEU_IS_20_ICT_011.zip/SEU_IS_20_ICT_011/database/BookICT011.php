<?php
class BookICT011 {
    private $id;
    private $title;
    private $author;
    private $isbn;
    private $price;
    private $description;
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function setBookID($id) {
        $this->id = $id;
    }

    public function setTitle($title) {
        $this->title = $title;
    }

    public function setAuthor($author) {
        $this->author = $author;
    }

    public function setISBN($isbn) {
        $this->isbn = $isbn;
    }

    public function setPrice($price) {
        $this->price = $price;
    }

    public function setDescription($description) {
        $this->description = $description;
    }

    public function create() {
        $query = "INSERT INTO `bookICT011` (`title`, `author`, `ISBN`, `price`, `description`) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        if ($stmt === false) {
            return false;
        }

        $stmt->bind_param('sssds', $this->title, $this->author, $this->isbn, $this->price, $this->description);
        $result = $stmt->execute();
        $stmt->close();
        return $result;
    }

    public function update() {
        $query = "UPDATE `bookICT011` SET `title` = ?, `author` = ?, `ISBN` = ?, `price` = ?, `description` = ? WHERE `id` = ?";
        $stmt = $this->conn->prepare($query);
        if ($stmt === false) {
            return false;
        }

        $stmt->bind_param('ssssdi', $this->title, $this->author, $this->isbn, $this->price, $this->description, $this->id);
        $result = $stmt->execute();
        $stmt->close();
        return $result;
    }

    public function delete() {
        $query = "DELETE FROM `bookICT011` WHERE `id` = ?";
        $stmt = $this->conn->prepare($query);
        if ($stmt === false) {
            return false;
        }

        $stmt->bind_param('i', $this->id);
        $result = $stmt->execute();
        $stmt->close();
        return $result;
    }

    public function read() {
        $query = "SELECT * FROM `bookICT011`";
        $result = $this->conn->query($query);
        return $result;
    }
}
?>
