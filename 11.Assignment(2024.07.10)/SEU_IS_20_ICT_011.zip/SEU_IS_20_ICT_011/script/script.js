async function add() {
    const title = document.getElementById("title").value;
    const author = document.getElementById("author").value;
    const isbn = document.getElementById("isbn").value;
    const price = document.getElementById("price").value;
    const description = document.getElementById("description").value;

    const response = await fetch('php/insert.php', {
        method: "POST",
        body: JSON.stringify({ title, author, isbn, price, description }),
        headers: { 'Content-Type': 'application/json' }
    });

    const result = await response.json();
    alert(result.message);
    loadBooks();
}

async function update() {
    const id = prompt("Enter the Book ID to update:");
    if(!id) return;

    const title = document.getElementById("title").value;
    const author = document.getElementById("author").value;
    const isbn = document.getElementById("isbn").value;
    const price = document.getElementById("price").value;
    const description = document.getElementById("description").value;

    const response = await fetch('php/update.php', {
        method: "POST",
        body: JSON.stringify({ id, title, author, isbn, price, description }),
        headers: { 'Content-Type': 'application/json' }
    });

    const result = await response.json();
    alert(result.message);
    loadBooks();
}

async function deleteBook() {
    const id = prompt("Enter the Book ID to delete:");
    if (!id) return;

    const response = await fetch('php/delete.php', {
        method: "POST",
        body: JSON.stringify({ id }),
        headers: { 'Content-Type': 'application/json' }
    });

    const result = await response.json();
    alert(result.message);
    loadBooks();
}

async function loadBooks() {
    const response = await fetch('php/read.php');
    const books = await response.json();

    const tableBody = document.getElementById("book-table-body");
    tableBody.innerHTML = "";

    books.forEach(book => {
        const row = `
            <tr>
                <td>${book.id}</td>
                <td>${book.title}</td>
                <td>${book.author}</td>
                <td>${book.ISBN}</td>
                <td>${book.price}</td>
                <td>${book.description}</td>
            </tr>
        `;
        tableBody.innerHTML += row;
    });
}

window.onload = loadBooks;
